var interfacecom_1_1kumakore_1_1_action_match_get_closed_1_1_i_kumakore =
[
    [ "onActionMatchCompletedListGet", "interfacecom_1_1kumakore_1_1_action_match_get_closed_1_1_i_kumakore.html#a83369ceef172f32ebdb785afd257329a", null ]
];