var classcom_1_1kumakore_1_1_open_match_map =
[
    [ "OpenMatchMap", "classcom_1_1kumakore_1_1_open_match_map.html#a6bb3e6cbd23069176d5b484d90bff208", null ],
    [ "createNewMatch", "classcom_1_1kumakore_1_1_open_match_map.html#a0fbec1407429fd46afada54ab24296bc", null ],
    [ "createRandomMatch", "classcom_1_1kumakore_1_1_open_match_map.html#aebb767a7c5f73bf85fcfbd01183a34cd", null ],
    [ "get", "classcom_1_1kumakore_1_1_open_match_map.html#a0277f4a4a11d75541171dfbfb91501c9", null ],
    [ "getMyTurn", "classcom_1_1kumakore_1_1_open_match_map.html#ac944d867399112f0eefe2650dded9ae9", null ],
    [ "getTheirTurn", "classcom_1_1kumakore_1_1_open_match_map.html#a859cff70df59803851a6fe9f75e9f6c6", null ]
];