var interfacecom_1_1kumakore_1_1_action_match_close_1_1_i_kumakore =
[
    [ "onActionMatchClose", "interfacecom_1_1kumakore_1_1_action_match_close_1_1_i_kumakore.html#a1b7040e8d470cc2c4cb6a852a760a9df", null ]
];