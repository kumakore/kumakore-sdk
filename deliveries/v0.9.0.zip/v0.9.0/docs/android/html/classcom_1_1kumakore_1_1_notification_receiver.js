var classcom_1_1kumakore_1_1_notification_receiver =
[
    [ "onReceive", "classcom_1_1kumakore_1_1_notification_receiver.html#afcecf0d74cd988fae3316d09dc8a1f1b", null ]
];