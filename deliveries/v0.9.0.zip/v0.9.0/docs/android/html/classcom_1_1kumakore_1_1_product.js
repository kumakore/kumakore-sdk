var classcom_1_1kumakore_1_1_product =
[
    [ "getCategory", "classcom_1_1kumakore_1_1_product.html#a809e259fe6e36c8496373230349d2945", null ],
    [ "getCostInDollars", "classcom_1_1kumakore_1_1_product.html#abf552a168b45dc41aec2b10a2f7c9e23", null ],
    [ "getCostInItems", "classcom_1_1kumakore_1_1_product.html#a7644f4940eb34a49a812000a146b809c", null ],
    [ "getCreatedAt", "classcom_1_1kumakore_1_1_product.html#a148115b77b2e348976c548a17c102d95", null ],
    [ "getEarnable", "classcom_1_1kumakore_1_1_product.html#ab8d43042822186dcd98e1120510aa940", null ],
    [ "getInAppIds", "classcom_1_1kumakore_1_1_product.html#ac2dbea703b7a92272f8b151890b9db1b", null ],
    [ "getIsBundle", "classcom_1_1kumakore_1_1_product.html#ac6bd983038f20f7a53b7e37e2ad222bd", null ],
    [ "getName", "classcom_1_1kumakore_1_1_product.html#a776ba858b47faa7205fd4dc4ac449aa6", null ],
    [ "getProductId", "classcom_1_1kumakore_1_1_product.html#a82c50646ccc9712f2ae47b8c8d3eac93", null ],
    [ "getRewardItems", "classcom_1_1kumakore_1_1_product.html#a5c00b0e30188323ec737bcab53d11931", null ],
    [ "getUpdatedAt", "classcom_1_1kumakore_1_1_product.html#add171ea7a7bdf5817ef2faf469ddec5f", null ]
];