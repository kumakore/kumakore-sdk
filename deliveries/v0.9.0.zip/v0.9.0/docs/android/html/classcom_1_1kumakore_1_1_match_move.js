var classcom_1_1kumakore_1_1_match_move =
[
    [ "getAttackItems", "classcom_1_1kumakore_1_1_match_move.html#ae12895710c138ade394ad7afc5c1273e", null ],
    [ "getCreatedUTC", "classcom_1_1kumakore_1_1_match_move.html#aac6482853aa75c1a1070f7bf6f5a66b9", null ],
    [ "getData", "classcom_1_1kumakore_1_1_match_move.html#a3756718518de323229609c4d3e38450f", null ],
    [ "getMoveId", "classcom_1_1kumakore_1_1_match_move.html#ab3dae046229f3d46901868872efbb17a", null ],
    [ "getMoveNumber", "classcom_1_1kumakore_1_1_match_move.html#a51c23cc69a05900b38457e96fa43aafb", null ],
    [ "getRewardItems", "classcom_1_1kumakore_1_1_match_move.html#ad60d2b6a4171e972aa42a4dff56c52ba", null ],
    [ "getSelectedItems", "classcom_1_1kumakore_1_1_match_move.html#a1478f63367dcd78cd4eb6ab9aec9549d", null ],
    [ "getUpdatedUTC", "classcom_1_1kumakore_1_1_match_move.html#a517e5262e144d85132260337db607229", null ],
    [ "getUserId", "classcom_1_1kumakore_1_1_match_move.html#a84532b5aa66665867e2861d76b04398c", null ]
];