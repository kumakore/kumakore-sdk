var group___a_c_t_i_o_n_s___f_r_i_e_n_d =
[
    [ "deleteFriend", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#gaf9054605179801b8439c7e318f5aa9dd", null ],
    [ "deleteFriend", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga21cff7a9bf8d19dfdfdc370381fdc612", null ],
    [ "getFriendInvitations", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#gaf87364572d2d63c5d7bc64b7304b74a7", null ],
    [ "getOpponents", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga521c9af8e00a7cd9edca91a5a38db262", null ],
    [ "sendFriendInvite", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga284dad9a270d48740f2162106d6835b8", null ],
    [ "sendInviteResponse", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga7535dbbd4ee199027f4fb16a71e1e0b0", null ]
];