var classcom_1_1kumakore_1_1_device =
[
    [ "finalize", "classcom_1_1kumakore_1_1_device.html#a8ed8ccc4631b23d4791ab554becaa1f2", null ],
    [ "mute", "classcom_1_1kumakore_1_1_device.html#a153e13435f1ee82146b2cc06831b3cb8", null ],
    [ "register", "classcom_1_1kumakore_1_1_device.html#aacb220d8517e536b992b17b285146e03", null ],
    [ "setDeviceBadge", "classcom_1_1kumakore_1_1_device.html#a581f6bb58f6db1a19b705f5c9612c4ce", null ],
    [ "unmute", "classcom_1_1kumakore_1_1_device.html#a78497af96806537dbf3f7d6011d9d12d", null ]
];