var classcom_1_1kumakore_1_1_action_friend_remove =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_friend_remove_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_friend_remove_1_1_i_kumakore" ],
    [ "ActionFriendRemove", "classcom_1_1kumakore_1_1_action_friend_remove.html#a5f54972669f6f53e75944e4d66690334", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_friend_remove.html#add9980969b6b2252120bbffd36a07d77", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_friend_remove.html#a0d086e51982d7bbb67bee6bf5d75f480", null ]
];