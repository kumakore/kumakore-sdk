var classcom_1_1kumakore_1_1_chat_message =
[
    [ "ChatMessage", "classcom_1_1kumakore_1_1_chat_message.html#a5f2c4e1adf63cee6678266bda632e071", null ],
    [ "getDate", "classcom_1_1kumakore_1_1_chat_message.html#ad3e66eecc1b28ef69d9fa94133e88176", null ],
    [ "getMsg", "classcom_1_1kumakore_1_1_chat_message.html#a4e275009f6f9972358cc43b55c4848e1", null ],
    [ "getUserId", "classcom_1_1kumakore_1_1_chat_message.html#ac61a29721b4d83084240f313db909a8e", null ],
    [ "isRead", "classcom_1_1kumakore_1_1_chat_message.html#a2055f44fb7431e706a5d95ec59c41dc9", null ]
];