var classcom_1_1kumakore_1_1_notification =
[
    [ "getEnabled", "classcom_1_1kumakore_1_1_notification.html#a8da4c30bd408cb7d127c422fc55c6c6e", null ],
    [ "init", "classcom_1_1kumakore_1_1_notification.html#a670f0dacb6317c138d1b1e5be5903ce1", null ],
    [ "init", "classcom_1_1kumakore_1_1_notification.html#afe8fc573e089e49483093d2e7b550fbb", null ],
    [ "isReady", "classcom_1_1kumakore_1_1_notification.html#a5a91fd1f412b761677be4470d0e0a5e2", null ],
    [ "register", "classcom_1_1kumakore_1_1_notification.html#ac6293406ca7e5f14c4b805331d84d3ff", null ],
    [ "setEnabled", "classcom_1_1kumakore_1_1_notification.html#a97846aa97c3f238f2aa31dac210d0865", null ],
    [ "setEnabled", "classcom_1_1kumakore_1_1_notification.html#a1ed43929cc43c9a3cddd972f9a98db10", null ],
    [ "unregister", "classcom_1_1kumakore_1_1_notification.html#a64386deeede7d2a7656f9e8b255c6e69", null ]
];