var classcom_1_1kumakore_1_1_action_user_signup =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_user_signup_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_user_signup_1_1_i_kumakore" ],
    [ "ActionUserSignup", "classcom_1_1kumakore_1_1_action_user_signup.html#ab24db9cd79901699e21823372df4993b", null ],
    [ "getEmail", "classcom_1_1kumakore_1_1_action_user_signup.html#a253364a9153527309828f9c2b055e364", null ],
    [ "getName", "classcom_1_1kumakore_1_1_action_user_signup.html#ace94a3b901392e8b160cbc74558f8db7", null ],
    [ "getSessionId", "classcom_1_1kumakore_1_1_action_user_signup.html#ad3f1d3f5209dcf5129a173b1d1afc750", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_user_signup.html#aaa8b118438385161192d8428f5dfdbc0", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_user_signup.html#ae14898972ef4675847610e2813c1665b", null ],
    [ "setEmail", "classcom_1_1kumakore_1_1_action_user_signup.html#a671c3b1c66d2fafc22c4b02000614b36", null ],
    [ "setName", "classcom_1_1kumakore_1_1_action_user_signup.html#a6faa16b4631b1ba1bf962fda7f409d59", null ]
];