var classcom_1_1kumakore_1_1_kumakore_preferences =
[
    [ "Editor", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor.html", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor" ],
    [ "edit", "classcom_1_1kumakore_1_1_kumakore_preferences.html#aa74f84d3ad358952ed3134a5e3a97e6b", null ],
    [ "getBoolean", "classcom_1_1kumakore_1_1_kumakore_preferences.html#afcf982c0623bfeb21ee8e436bc63b49f", null ],
    [ "getInt", "classcom_1_1kumakore_1_1_kumakore_preferences.html#ac67f196659872ad33281407c576e7a94", null ],
    [ "getString", "classcom_1_1kumakore_1_1_kumakore_preferences.html#aa5ca473e720a273298c703c5197e32f6", null ]
];