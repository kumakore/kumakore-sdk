var classcom_1_1kumakore_1_1_action_match_resign =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_resign_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_resign_1_1_i_kumakore" ],
    [ "ActionMatchResign", "classcom_1_1kumakore_1_1_action_match_resign.html#a8fcfe9305a2bac054446ceb997df43ca", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_resign.html#a1588e0bd23a9419d8d8704e3e3de3706", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_resign.html#ae08425cb3d19ad94c6e1f74b6c4434fc", null ]
];