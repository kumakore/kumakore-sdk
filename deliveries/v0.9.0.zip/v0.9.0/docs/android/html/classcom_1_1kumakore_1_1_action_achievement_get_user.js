var classcom_1_1kumakore_1_1_action_achievement_get_user =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_achievement_get_user_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_achievement_get_user_1_1_i_kumakore" ],
    [ "ActionAchievementGetUser", "classcom_1_1kumakore_1_1_action_achievement_get_user.html#acf1a6640c5ab821d5cc2037d9c50e1be", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_achievement_get_user.html#a0aa3da44720f739d139b63ba4364a51e", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_achievement_get_user.html#a7f0a08db3507a98f284613037c44b7d8", null ]
];