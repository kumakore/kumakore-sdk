var classcom_1_1kumakore_1_1_action_match_get_status =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_get_status_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_get_status_1_1_i_kumakore" ],
    [ "ActionMatchGetStatus", "classcom_1_1kumakore_1_1_action_match_get_status.html#aa1f1226bcc61085ff01eaca6ade89f37", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_get_status.html#a11e3979086e78b26ffd033d520f9fe74", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_get_status.html#a4328b63aa6f0256c8a3b271d0ecbcbfa", null ]
];