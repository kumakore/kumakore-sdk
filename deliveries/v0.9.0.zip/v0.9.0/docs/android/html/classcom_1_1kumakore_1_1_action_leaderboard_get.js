var classcom_1_1kumakore_1_1_action_leaderboard_get =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_leaderboard_get_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_leaderboard_get_1_1_i_kumakore" ],
    [ "ActionLeaderboardGet", "classcom_1_1kumakore_1_1_action_leaderboard_get.html#a03ad3f086ef927769a23cd674e0d08e8", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_leaderboard_get.html#a831a543f7083849c9991dd07ceed4199", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_leaderboard_get.html#a366239d141c28907f8c29f87f5b9143d", null ]
];