var classcom_1_1kumakore_1_1_open_match =
[
    [ "accept", "classcom_1_1kumakore_1_1_open_match.html#a815d31dfc671916f7fedb8460696fc09", null ],
    [ "close", "classcom_1_1kumakore_1_1_open_match.html#ac487260af1857571081db7994566c0a6", null ],
    [ "getResignedId", "classcom_1_1kumakore_1_1_open_match.html#a50c9d7a379bbdf0fa7cbfb45d78947e5", null ],
    [ "reject", "classcom_1_1kumakore_1_1_open_match.html#a72a0f129e6365a2af7e048b2dbf80576", null ],
    [ "resign", "classcom_1_1kumakore_1_1_open_match.html#ae3bb9c27add89fd45f6145463497652f", null ],
    [ "seletcItems", "classcom_1_1kumakore_1_1_open_match.html#a1a512d2c5375b0fe3738297d28b060d6", null ],
    [ "sendMove", "classcom_1_1kumakore_1_1_open_match.html#aa74b406dd5e9a03d6be6344465b3ff75", null ],
    [ "sendNudge", "classcom_1_1kumakore_1_1_open_match.html#a4c45939e16d9750f12a2a99992ffb797", null ],
    [ "chatMessages", "classcom_1_1kumakore_1_1_open_match.html#af4028a222ea76e0f616f2915b5418eba", null ]
];