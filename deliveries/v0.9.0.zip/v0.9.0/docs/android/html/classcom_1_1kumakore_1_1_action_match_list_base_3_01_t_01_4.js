var classcom_1_1kumakore_1_1_action_match_list_base_3_01_t_01_4 =
[
    [ "ActionMatchListBase", "classcom_1_1kumakore_1_1_action_match_list_base_3_01_t_01_4.html#a2716824f363f5a68d064921509210d1c", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_list_base_3_01_t_01_4.html#aae22bf7a462f91705f5b23a2483b708e", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_list_base_3_01_t_01_4.html#aa170923855d63b4e2fdcdd05876dff39", null ],
    [ "matchList", "classcom_1_1kumakore_1_1_action_match_list_base_3_01_t_01_4.html#ad43d9ceecfab6d08a3f4cb3185bb595b", null ]
];