var classcom_1_1kumakore_1_1_action_match_close =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_close_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_close_1_1_i_kumakore" ],
    [ "ActionMatchClose", "classcom_1_1kumakore_1_1_action_match_close.html#a9a4731618659417416d89e91a4b794cb", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_close.html#a874af8e308ad6f2ecaa9a4acd3602695", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_close.html#a7c8a5a6eef036fb548e285fd44020ab8", null ]
];