var interfacecom_1_1kumakore_1_1_action_facebook_deauthorize_1_1_i_kumakore =
[
    [ "onActionFacebookDeauthorize", "interfacecom_1_1kumakore_1_1_action_facebook_deauthorize_1_1_i_kumakore.html#aef78c89d96195690e7017fbe8aa410b9", null ]
];