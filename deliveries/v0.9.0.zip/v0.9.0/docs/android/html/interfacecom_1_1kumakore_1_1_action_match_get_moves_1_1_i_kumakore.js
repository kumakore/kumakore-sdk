var interfacecom_1_1kumakore_1_1_action_match_get_moves_1_1_i_kumakore =
[
    [ "onActionMatchGetMoves", "interfacecom_1_1kumakore_1_1_action_match_get_moves_1_1_i_kumakore.html#a8b505cae4aff5a8fdb467ff586d65627", null ]
];