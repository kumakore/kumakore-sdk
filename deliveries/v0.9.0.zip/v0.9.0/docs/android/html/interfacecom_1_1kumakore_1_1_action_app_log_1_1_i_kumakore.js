var interfacecom_1_1kumakore_1_1_action_app_log_1_1_i_kumakore =
[
    [ "onAppLog", "interfacecom_1_1kumakore_1_1_action_app_log_1_1_i_kumakore.html#a2edb15bd9a3605e8590c79bb7de98d38", null ]
];