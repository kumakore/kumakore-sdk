var classcom_1_1kumakore_1_1_closed_match_map =
[
    [ "ClosedMatchMap", "classcom_1_1kumakore_1_1_closed_match_map.html#af081d682ea1ca33c1595c696e20187d7", null ],
    [ "get", "classcom_1_1kumakore_1_1_closed_match_map.html#aba6ea16e09690e0fd3e6274a7b5d1b0a", null ]
];