var classcom_1_1kumakore_1_1_friend_facebook =
[
    [ "getFacebook_id", "group___a_c_t_i_o_n_s___u_s_e_r.html#gad9f8204072c473bbf187e8f2654da8c0", null ],
    [ "getFirstName", "group___a_c_t_i_o_n_s___u_s_e_r.html#ga5aa8b63113c690973b703b8b95f4ecc2", null ],
    [ "getLastName", "group___a_c_t_i_o_n_s___u_s_e_r.html#gaf6d46a9e598800acbd77321a703a0674", null ],
    [ "getPictureUrl", "group___a_c_t_i_o_n_s___u_s_e_r.html#gab3b98012d1279fcfddb8f52ec2e69d53", null ],
    [ "getUser_id", "group___a_c_t_i_o_n_s___u_s_e_r.html#ga02a20f98c9f4df3ec9e6028fb9ad4e6e", null ],
    [ "getUsername", "group___a_c_t_i_o_n_s___u_s_e_r.html#gac1bdb2d49792ccca472d730725e7242d", null ],
    [ "isSilhouette", "group___a_c_t_i_o_n_s___u_s_e_r.html#ga18a2ea773327c4121ca92d009b4488e3", null ]
];