var enumcom_1_1kumakore_1_1_log_levels =
[
    [ "LogLevels", "enumcom_1_1kumakore_1_1_log_levels.html#a627ef796330e843246d465889bd791e5", null ],
    [ "toString", "enumcom_1_1kumakore_1_1_log_levels.html#ae05f83359b155bf31b2fe067f196cc7f", null ],
    [ "CRITICAL", "enumcom_1_1kumakore_1_1_log_levels.html#ad51a1af72d21ac13cc5cb399a7ca0a39", null ],
    [ "DEBUG", "enumcom_1_1kumakore_1_1_log_levels.html#a0fd6f21e88fd02ba0cbabbdd74013b8f", null ],
    [ "ERROR", "enumcom_1_1kumakore_1_1_log_levels.html#a2996c0cc7bc3a46e7b5491856606a747", null ],
    [ "INFO", "enumcom_1_1kumakore_1_1_log_levels.html#a96ea6adbac9e82fcf15ec0527d8d77fa", null ],
    [ "NONE", "enumcom_1_1kumakore_1_1_log_levels.html#a06d2af563e0984e1ca686f7418dc287a", null ],
    [ "WARNING", "enumcom_1_1kumakore_1_1_log_levels.html#a55b135b7c4f4b0153de4240e44282fef", null ]
];