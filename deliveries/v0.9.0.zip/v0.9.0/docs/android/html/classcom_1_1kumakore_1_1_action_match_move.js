var classcom_1_1kumakore_1_1_action_match_move =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_move_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_move_1_1_i_kumakore" ],
    [ "ActionMatchMove", "classcom_1_1kumakore_1_1_action_match_move.html#a4400e5c77ebe80171df0e6878b914072", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_move.html#aa095e8734fa142c6522cb90880bbefaa", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_move.html#adb1317a98a252f64ffcb0004b2eb9a47", null ]
];