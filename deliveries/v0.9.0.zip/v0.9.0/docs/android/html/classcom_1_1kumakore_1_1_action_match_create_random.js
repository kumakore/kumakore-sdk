var classcom_1_1kumakore_1_1_action_match_create_random =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_create_random_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_create_random_1_1_i_kumakore" ],
    [ "ActionMatchCreateRandom", "classcom_1_1kumakore_1_1_action_match_create_random.html#a88be7be60cad2a8123cb50ca1703b989", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_create_random.html#a48c69b0af24add73a31a1713d4cce416", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_create_random.html#a9ef3aa76c314c8077b96bd7d5747a690", null ]
];