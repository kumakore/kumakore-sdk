var annotated =
[
    [ "com", null, [
      [ "kumakore", "namespacecom_1_1kumakore.html", "namespacecom_1_1kumakore" ]
    ] ]
];