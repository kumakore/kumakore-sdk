var classcom_1_1kumakore_1_1_friend =
[
    [ "getAvatar", "classcom_1_1kumakore_1_1_friend.html#a90ab9cc6ebbfe677631fec3bdaac03f2", null ],
    [ "getInstalled", "classcom_1_1kumakore_1_1_friend.html#a73e06de5e0261038b2091239b5ddd7f2", null ],
    [ "getName", "classcom_1_1kumakore_1_1_friend.html#a493a083ba3ecbc12c44174e377004353", null ]
];