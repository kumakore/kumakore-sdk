var classcom_1_1kumakore_1_1_action_match_get_closed =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_get_closed_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_get_closed_1_1_i_kumakore" ],
    [ "ActionMatchGetClosed", "classcom_1_1kumakore_1_1_action_match_get_closed.html#a379e36bd538936523edd6b914fa0ca42", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_get_closed.html#adabb1a1a08547ee2b1fb2c1d985041cb", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_get_closed.html#ad80997328e6da653a3dc7c61775082fe", null ]
];