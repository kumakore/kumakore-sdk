var classcom_1_1kumakore_1_1_notification_service =
[
    [ "NotificationService", "classcom_1_1kumakore_1_1_notification_service.html#af89a0b9f83d7c9615e08c5904087718c", null ],
    [ "onHandleIntent", "classcom_1_1kumakore_1_1_notification_service.html#af12330be03fbe54ed295ec7e1888086f", null ],
    [ "RaiseNotification", "classcom_1_1kumakore_1_1_notification_service.html#a4fd489aefaf07af830ca09e21b4d79de", null ]
];