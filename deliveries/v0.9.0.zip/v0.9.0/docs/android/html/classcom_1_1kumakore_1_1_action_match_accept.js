var classcom_1_1kumakore_1_1_action_match_accept =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_accept_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_accept_1_1_i_kumakore" ],
    [ "ActionMatchAccept", "classcom_1_1kumakore_1_1_action_match_accept.html#a073ffc4b11a2236c6c9140e0988f735d", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_accept.html#a325a2595b9c17050fa249a6941d719e0", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_accept.html#abdb25902dbfe6f2ea431e6204651bb4b", null ]
];