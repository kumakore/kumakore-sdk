var classcom_1_1kumakore_1_1_action_app_log =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_app_log_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_app_log_1_1_i_kumakore" ],
    [ "ActionAppLog", "classcom_1_1kumakore_1_1_action_app_log.html#afdc88420d06853d9c62d383f42495292", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_app_log.html#a160c8d15159679f045285fd490aaa969", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_app_log.html#a8ed9edd0c5bccd87022c53dbe37cb543", null ]
];