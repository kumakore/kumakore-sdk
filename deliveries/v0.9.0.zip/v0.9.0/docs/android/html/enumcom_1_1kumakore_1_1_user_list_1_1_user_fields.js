var enumcom_1_1kumakore_1_1_user_list_1_1_user_fields =
[
    [ "Email", "enumcom_1_1kumakore_1_1_user_list_1_1_user_fields.html#a8b4d014a72fb4e1c5a755d69b92859f3", null ],
    [ "FacebookId", "enumcom_1_1kumakore_1_1_user_list_1_1_user_fields.html#a00726337905e9f00248f83adaa665775", null ],
    [ "Id", "enumcom_1_1kumakore_1_1_user_list_1_1_user_fields.html#a395e28ddfde376181b4e1996bc5b839f", null ],
    [ "Name", "enumcom_1_1kumakore_1_1_user_list_1_1_user_fields.html#a57dfff5baeeb1ee18376e35e760c11ab", null ],
    [ "PushEnabled", "enumcom_1_1kumakore_1_1_user_list_1_1_user_fields.html#a7f0372872f2f8ec8690f3d435ce0b873", null ],
    [ "SessionId", "enumcom_1_1kumakore_1_1_user_list_1_1_user_fields.html#af3b68e496192c61ce316bc50b3559379", null ]
];