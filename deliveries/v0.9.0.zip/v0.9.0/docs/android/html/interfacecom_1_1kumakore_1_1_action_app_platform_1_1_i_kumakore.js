var interfacecom_1_1kumakore_1_1_action_app_platform_1_1_i_kumakore =
[
    [ "onActionAppPlatform", "interfacecom_1_1kumakore_1_1_action_app_platform_1_1_i_kumakore.html#a6873a7c708ec051f237023f02ee73184", null ]
];