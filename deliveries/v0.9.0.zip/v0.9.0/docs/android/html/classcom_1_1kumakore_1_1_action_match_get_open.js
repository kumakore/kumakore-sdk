var classcom_1_1kumakore_1_1_action_match_get_open =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_get_open_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_get_open_1_1_i_kumakore" ],
    [ "ActionMatchGetOpen", "classcom_1_1kumakore_1_1_action_match_get_open.html#a4902852a517c25785edb80ab6450b08c", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_get_open.html#ae1352a3cffac6549db86412b9389fea6", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_get_open.html#ae951bc387219a85ce6cd6a8ce23d7d14", null ]
];