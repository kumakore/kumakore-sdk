var interfacecom_1_1kumakore_1_1_action_device_set_badge_1_1_i_kumakore =
[
    [ "onActionDeviceSetBadge", "interfacecom_1_1kumakore_1_1_action_device_set_badge_1_1_i_kumakore.html#ac65b0bab88a336d973f477b5989d65bb", null ]
];