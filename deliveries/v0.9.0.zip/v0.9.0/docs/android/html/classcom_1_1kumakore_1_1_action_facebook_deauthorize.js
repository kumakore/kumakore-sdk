var classcom_1_1kumakore_1_1_action_facebook_deauthorize =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_facebook_deauthorize_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_facebook_deauthorize_1_1_i_kumakore" ],
    [ "ActionFacebookDeauthorize", "classcom_1_1kumakore_1_1_action_facebook_deauthorize.html#a433e2bbd07087565db4a819575d29d5e", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_facebook_deauthorize.html#a5f6c6e94a9d72a2d5e8c6059fb8e83ab", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_facebook_deauthorize.html#acc276ff7f4879c37113fbff897b08169", null ]
];