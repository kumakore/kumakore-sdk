var interfacecom_1_1kumakore_1_1_action_datastore_get_1_1_i_kumakore =
[
    [ "onActionDatastoreCreate", "interfacecom_1_1kumakore_1_1_action_datastore_get_1_1_i_kumakore.html#abc50478b4a83cbe6e11b28baeb946119", null ]
];