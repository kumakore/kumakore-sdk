var classcom_1_1kumakore_1_1_action_inventory_add =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_inventory_add_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_inventory_add_1_1_i_kumakore" ],
    [ "ActionInventoryAdd", "classcom_1_1kumakore_1_1_action_inventory_add.html#a6a7f52d814906039ebca68dad91710c3", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_inventory_add.html#a48149123872d133f003a11d419d65d79", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_inventory_add.html#acac6b7a5c5c8b4a39d2849fab1bc3ab0", null ]
];