var classcom_1_1kumakore_1_1_reward_map =
[
    [ "get", "classcom_1_1kumakore_1_1_reward_map.html#ac48bd859260495be76d5742c46331db0", null ],
    [ "getFacebookMatchReward", "classcom_1_1kumakore_1_1_reward_map.html#a47a6f7919e98c9183bfaf7ef3dcb7c34", null ],
    [ "getFacebookSignupReward", "classcom_1_1kumakore_1_1_reward_map.html#aeac1ad30bd15b3d3b7b965992fa4a49b", null ],
    [ "getSignupReward", "classcom_1_1kumakore_1_1_reward_map.html#a5b3d9669a7bc1afaf51e2084f11d4b48", null ],
    [ "setRewards", "classcom_1_1kumakore_1_1_reward_map.html#a4d12d17dda9c1f774d99813a09eab357", null ]
];