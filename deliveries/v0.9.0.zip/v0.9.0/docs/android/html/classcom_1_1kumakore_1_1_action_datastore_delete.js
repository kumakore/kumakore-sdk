var classcom_1_1kumakore_1_1_action_datastore_delete =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_datastore_delete_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_datastore_delete_1_1_i_kumakore" ],
    [ "ActionDatastoreDelete", "classcom_1_1kumakore_1_1_action_datastore_delete.html#ad7069030b3e789a8b748aa9118d4db4e", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_datastore_delete.html#ab627c0c0f511223bdd684ae2dba091d7", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_datastore_delete.html#abbcd5d0db4cfcf08ea71068dc3f6c7ae", null ]
];