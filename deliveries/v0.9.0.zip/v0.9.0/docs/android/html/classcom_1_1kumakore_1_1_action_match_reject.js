var classcom_1_1kumakore_1_1_action_match_reject =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_reject_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_reject_1_1_i_kumakore" ],
    [ "ActionMatchReject", "classcom_1_1kumakore_1_1_action_match_reject.html#a1a6bdb0e43381fb117326b776d19a828", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_reject.html#a8f171b417264c9fc43f1de78fefd2431", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_reject.html#ae6a35b12693237b0978c447c28fed2be", null ]
];