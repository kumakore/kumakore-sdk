var classcom_1_1kumakore_1_1_action_leaderboard_set_score =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_leaderboard_set_score_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_leaderboard_set_score_1_1_i_kumakore" ],
    [ "ActionLeaderboardSetScore", "classcom_1_1kumakore_1_1_action_leaderboard_set_score.html#a82f45fa11ee8d529eaffebd2fab963be", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_leaderboard_set_score.html#a302e61714d5d612ce5880720417d288c", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_leaderboard_set_score.html#a29520356299d764b84b9082dfabc77c7", null ]
];