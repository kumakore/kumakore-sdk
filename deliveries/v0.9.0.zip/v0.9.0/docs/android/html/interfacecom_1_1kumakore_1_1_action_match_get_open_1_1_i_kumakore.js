var interfacecom_1_1kumakore_1_1_action_match_get_open_1_1_i_kumakore =
[
    [ "onActionMatchCurrentListGet", "interfacecom_1_1kumakore_1_1_action_match_get_open_1_1_i_kumakore.html#a9ad556062a3ea9b20b4d21da2731ae30", null ]
];