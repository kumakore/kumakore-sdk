var classcom_1_1kumakore_1_1_app_achievement =
[
    [ "getApp_id", "classcom_1_1kumakore_1_1_app_achievement.html#a1bbf936b903820636809c7d3ddcddb71", null ],
    [ "getCreated_at", "classcom_1_1kumakore_1_1_app_achievement.html#ae27c4d64d56fbd116ac70ae606087a3a", null ],
    [ "getDescription", "classcom_1_1kumakore_1_1_app_achievement.html#aaa16e3dd8581602fd72e0e21fc32960e", null ],
    [ "getHidden", "classcom_1_1kumakore_1_1_app_achievement.html#a24631fc07b1a6a1e4b8c0216eb8edfc0", null ],
    [ "getId", "classcom_1_1kumakore_1_1_app_achievement.html#a178df525e2549345b2512dd91aed60bf", null ],
    [ "getName", "classcom_1_1kumakore_1_1_app_achievement.html#a1ca12bb35fbc1862dbd545324be6d933", null ],
    [ "getTitle", "classcom_1_1kumakore_1_1_app_achievement.html#ad7adb90a03fadbb37f3af765ad3aafc1", null ],
    [ "getUpdated_at", "classcom_1_1kumakore_1_1_app_achievement.html#a6e9aa4a8c5f2d3d7ba2b7889483238a6", null ]
];