var classcom_1_1kumakore_1_1_datastore_object =
[
    [ "getCreatedAt", "classcom_1_1kumakore_1_1_datastore_object.html#a3c416a41ed5fb2568d2301d9774e6f26", null ],
    [ "getData", "classcom_1_1kumakore_1_1_datastore_object.html#a0ea10109f73bfb22726a627577ce87fa", null ],
    [ "getId", "classcom_1_1kumakore_1_1_datastore_object.html#a54145b9d773623475f5ac71aafe91b71", null ],
    [ "getName", "classcom_1_1kumakore_1_1_datastore_object.html#a2d5810930c97a2840daa2f97afd4eec4", null ],
    [ "getType", "classcom_1_1kumakore_1_1_datastore_object.html#ac7631f02273fc2d992244b9fcf367c85", null ],
    [ "getUpdatedAt", "classcom_1_1kumakore_1_1_datastore_object.html#ad568c278e148041f60f91a25a6608c8d", null ]
];