var classcom_1_1kumakore_1_1_action_datastore_create =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_datastore_create_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_datastore_create_1_1_i_kumakore" ],
    [ "ActionDatastoreCreate", "classcom_1_1kumakore_1_1_action_datastore_create.html#a43973b2b33ba654eb5e54a1730b34548", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_datastore_create.html#adda22d4fdcca6fa24559bd262ea9acda", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_datastore_create.html#a7a37ba503a223e9eda4fd89b224e7265", null ]
];