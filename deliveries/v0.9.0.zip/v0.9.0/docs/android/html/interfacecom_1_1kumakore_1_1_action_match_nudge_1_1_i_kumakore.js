var interfacecom_1_1kumakore_1_1_action_match_nudge_1_1_i_kumakore =
[
    [ "onActionMatchNudge", "interfacecom_1_1kumakore_1_1_action_match_nudge_1_1_i_kumakore.html#a4a9370359301348779afef9b1f2d6aa5", null ]
];