var classcom_1_1kumakore_1_1_action_app_platform =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_app_platform_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_app_platform_1_1_i_kumakore" ],
    [ "ActionAppPlatform", "classcom_1_1kumakore_1_1_action_app_platform.html#a5be3087468fb30ee7307b2427ae30d84", null ],
    [ "getCurrent", "classcom_1_1kumakore_1_1_action_app_platform.html#aa6a00f0a843329e6f19ff1a54d8dd21b", null ],
    [ "getCurrentPlatform", "classcom_1_1kumakore_1_1_action_app_platform.html#a50bc09de0f75b44859291f37636adff2", null ],
    [ "getMinimum", "classcom_1_1kumakore_1_1_action_app_platform.html#a78c486ed8783dda27d45dd72ec78b72f", null ],
    [ "getMinimumPlatform", "classcom_1_1kumakore_1_1_action_app_platform.html#a81db4f56df04c68bcb528e83d7ff2ccc", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_app_platform.html#aa75ed5927fffd3496d138669e31464cf", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_app_platform.html#a492ccab3f27ced0614eb6b382f857755", null ]
];