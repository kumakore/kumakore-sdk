var classcom_1_1kumakore_1_1_action_friend_get_opponents =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_friend_get_opponents_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_friend_get_opponents_1_1_i_kumakore" ],
    [ "ActionFriendGetOpponents", "classcom_1_1kumakore_1_1_action_friend_get_opponents.html#aa720230afdce7a378a3db598bb4e76bb", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_friend_get_opponents.html#af23cbb2ac62147420bcc3fa1d9524d73", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_friend_get_opponents.html#aff5d1ec27a6044383151e239e80309bb", null ]
];