var classcom_1_1kumakore_1_1_action_facebook_get_friends =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_facebook_get_friends_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_facebook_get_friends_1_1_i_kumakore" ],
    [ "ActionFacebookGetFriends", "classcom_1_1kumakore_1_1_action_facebook_get_friends.html#a89fbd9edf9714b8e9f37dc8c7db6b4a0", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_facebook_get_friends.html#a2dee844130e49240d0b3e02b77c8d8c6", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_facebook_get_friends.html#a8188d969692035c9651ead57fc702746", null ]
];