var interfacecom_1_1kumakore_1_1_action_datastore_delete_1_1_i_kumakore =
[
    [ "onActionDatastoreCreate", "interfacecom_1_1kumakore_1_1_action_datastore_delete_1_1_i_kumakore.html#a5467f192a3ea9cb070452b44995ecbac", null ]
];