var classcom_1_1kumakore_1_1_user_achievement =
[
    [ "getCreated_at", "classcom_1_1kumakore_1_1_user_achievement.html#a333f013be5053a73febf0ac36aebcfe9", null ],
    [ "getName", "classcom_1_1kumakore_1_1_user_achievement.html#a40e2865adfc3693ca096c54d11560bf1", null ],
    [ "getProgress", "classcom_1_1kumakore_1_1_user_achievement.html#aa2f4b3baccb7d704312c99d81b11d6b4", null ],
    [ "getUpdated_at", "classcom_1_1kumakore_1_1_user_achievement.html#a8130a6f5aa4d8d50689adee92029aa16", null ]
];