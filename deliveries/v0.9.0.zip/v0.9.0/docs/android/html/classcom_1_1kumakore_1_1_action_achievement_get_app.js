var classcom_1_1kumakore_1_1_action_achievement_get_app =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_achievement_get_app_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_achievement_get_app_1_1_i_kumakore" ],
    [ "ActionAchievementGetApp", "classcom_1_1kumakore_1_1_action_achievement_get_app.html#a1135f6af5e26a96d2a03d123201a5d53", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_achievement_get_app.html#a47760253b1497fe5786b31a2bd2a34ce", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_achievement_get_app.html#a9ccfcf8f2d554a4daaf5b1b5e43c8063", null ]
];