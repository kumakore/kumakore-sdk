var group___a_c_t_i_o_n_s___u_s_e_r =
[
    [ "ActionUserSignin", "classcom_1_1kumakore_1_1_action_user_signin.html", [
      [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_user_signin_1_1_i_kumakore.html", [
        [ "onActionUserSignin", "interfacecom_1_1kumakore_1_1_action_user_signin_1_1_i_kumakore.html#aaf9983b180bc53a7f22fd4cc580177bc", null ]
      ] ],
      [ "ActionUserSignin", "classcom_1_1kumakore_1_1_action_user_signin.html#a1971abe1934123ef684d80c3ffab6c17", null ],
      [ "onRequest", "classcom_1_1kumakore_1_1_action_user_signin.html#a19a1273950c86223dc24b678c61430c9", null ],
      [ "onResponse", "classcom_1_1kumakore_1_1_action_user_signin.html#a3fc65916b8f0adecc8b2ac0c6b15fad0", null ]
    ] ],
    [ "getFacebook_id", "group___a_c_t_i_o_n_s___u_s_e_r.html#gad9f8204072c473bbf187e8f2654da8c0", null ],
    [ "getFirstName", "group___a_c_t_i_o_n_s___u_s_e_r.html#ga5aa8b63113c690973b703b8b95f4ecc2", null ],
    [ "getLastName", "group___a_c_t_i_o_n_s___u_s_e_r.html#gaf6d46a9e598800acbd77321a703a0674", null ],
    [ "getPictureUrl", "group___a_c_t_i_o_n_s___u_s_e_r.html#gab3b98012d1279fcfddb8f52ec2e69d53", null ],
    [ "getUser_id", "group___a_c_t_i_o_n_s___u_s_e_r.html#ga02a20f98c9f4df3ec9e6028fb9ad4e6e", null ],
    [ "getUsername", "group___a_c_t_i_o_n_s___u_s_e_r.html#gac1bdb2d49792ccca472d730725e7242d", null ],
    [ "isSilhouette", "group___a_c_t_i_o_n_s___u_s_e_r.html#ga18a2ea773327c4121ca92d009b4488e3", null ]
];