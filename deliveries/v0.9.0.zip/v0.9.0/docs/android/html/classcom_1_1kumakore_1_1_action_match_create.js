var classcom_1_1kumakore_1_1_action_match_create =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_create_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_create_1_1_i_kumakore" ],
    [ "ActionMatchCreate", "classcom_1_1kumakore_1_1_action_match_create.html#a7e3b7cd5cbf304e7b41911bd32cfc857", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_create.html#ad3e490303612f78283e3f4f93a97cf95", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_create.html#aed8b3b5feb8e0c9a2fc06b0e533564a9", null ]
];