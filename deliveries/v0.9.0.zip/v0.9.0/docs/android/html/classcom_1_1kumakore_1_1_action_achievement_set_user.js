var classcom_1_1kumakore_1_1_action_achievement_set_user =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_achievement_set_user_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_achievement_set_user_1_1_i_kumakore" ],
    [ "ActionAchievementSetUser", "classcom_1_1kumakore_1_1_action_achievement_set_user.html#a55b20af1ebebf432abd84ba9b8ff34d9", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_achievement_set_user.html#ae3ab4c74e951087474d8bea1bc7a7fb7", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_achievement_set_user.html#a4afd4047333c7f8035b63857cfdace5f", null ]
];