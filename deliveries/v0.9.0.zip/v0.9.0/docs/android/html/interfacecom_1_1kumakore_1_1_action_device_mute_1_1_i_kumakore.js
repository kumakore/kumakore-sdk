var interfacecom_1_1kumakore_1_1_action_device_mute_1_1_i_kumakore =
[
    [ "onActionUserMuteDevice", "interfacecom_1_1kumakore_1_1_action_device_mute_1_1_i_kumakore.html#ac01f3b6e2f139e7e27bd84b380c79eef", null ]
];