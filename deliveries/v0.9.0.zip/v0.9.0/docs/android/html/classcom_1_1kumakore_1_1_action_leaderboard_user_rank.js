var classcom_1_1kumakore_1_1_action_leaderboard_user_rank =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_leaderboard_user_rank_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_leaderboard_user_rank_1_1_i_kumakore" ],
    [ "ActionLeaderboardUserRank", "classcom_1_1kumakore_1_1_action_leaderboard_user_rank.html#a0d9cc4d418ad4ccb82fdd3afa726a6d7", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_leaderboard_user_rank.html#a65cfe6d6ac970d1e2f1eabd2d7956c14", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_leaderboard_user_rank.html#a9ffad5f045e33f1bccd55961e820b69e", null ]
];