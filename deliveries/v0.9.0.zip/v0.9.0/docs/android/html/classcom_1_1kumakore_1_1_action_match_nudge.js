var classcom_1_1kumakore_1_1_action_match_nudge =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_nudge_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_nudge_1_1_i_kumakore" ],
    [ "ActionMatchNudge", "classcom_1_1kumakore_1_1_action_match_nudge.html#a671edda17cc3405f528af13551e122c9", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_nudge.html#a4c25c2475416ca9e9c99093ae233ffdb", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_nudge.html#afb6ebec655da8feebde2b81c47b62841", null ]
];