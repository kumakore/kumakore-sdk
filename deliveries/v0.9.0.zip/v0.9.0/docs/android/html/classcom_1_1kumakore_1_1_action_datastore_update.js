var classcom_1_1kumakore_1_1_action_datastore_update =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_datastore_update_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_datastore_update_1_1_i_kumakore" ],
    [ "ActionDatastoreUpdate", "classcom_1_1kumakore_1_1_action_datastore_update.html#a9391618353f37b73c80e3c1a74612ea3", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_datastore_update.html#a2cc1335c8d1329b4a095de95a07c7a37", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_datastore_update.html#aa53220219ba973e1951c17dd2d42b1fd", null ]
];