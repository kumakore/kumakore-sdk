var interfacecom_1_1kumakore_1_1_action_datastore_update_1_1_i_kumakore =
[
    [ "onActionDatastoreCreate", "interfacecom_1_1kumakore_1_1_action_datastore_update_1_1_i_kumakore.html#a01d4a5cfafe0350ead5a6631c245009c", null ]
];