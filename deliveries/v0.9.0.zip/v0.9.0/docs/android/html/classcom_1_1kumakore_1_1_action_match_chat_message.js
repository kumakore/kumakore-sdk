var classcom_1_1kumakore_1_1_action_match_chat_message =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_chat_message_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_chat_message_1_1_i_kumakore" ],
    [ "ActionMatchChatMessage", "classcom_1_1kumakore_1_1_action_match_chat_message.html#ae61cbc0f49e42c03a76cbc3ebab4def4", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_chat_message.html#a459f9a1387024b6045943bcc5f42bb9e", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_chat_message.html#a93ae1e3f7ea9c830d012d6d518d2f666", null ]
];