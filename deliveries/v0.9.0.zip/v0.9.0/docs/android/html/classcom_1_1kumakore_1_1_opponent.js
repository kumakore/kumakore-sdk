var classcom_1_1kumakore_1_1_opponent =
[
    [ "getAvatar", "classcom_1_1kumakore_1_1_opponent.html#affbc7a3df184620e301ed6da5bb95f02", null ],
    [ "getId", "classcom_1_1kumakore_1_1_opponent.html#aca4bee28eafdc5aa565556767e7986d1", null ],
    [ "getName", "classcom_1_1kumakore_1_1_opponent.html#a70eb7a3311319a87a3e3e7d4fdae93a4", null ]
];