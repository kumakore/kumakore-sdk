var classcom_1_1kumakore_1_1_leaderboard_member =
[
    [ "LeaderboardMember", "classcom_1_1kumakore_1_1_leaderboard_member.html#afa5e7f81b0d99d1e9bd7ceaaf684206b", null ],
    [ "getFriend", "classcom_1_1kumakore_1_1_leaderboard_member.html#a7fa85ca697975e2d991f94460359118d", null ],
    [ "getFriendFacebook", "classcom_1_1kumakore_1_1_leaderboard_member.html#a914ce387e0b2333982e98cdae1ab3678", null ],
    [ "getMemberId", "classcom_1_1kumakore_1_1_leaderboard_member.html#a1311fbbf5071968a6df837756799418f", null ],
    [ "getRank", "classcom_1_1kumakore_1_1_leaderboard_member.html#ad1c105a75834ca1d0b49607193082296", null ],
    [ "getScore", "classcom_1_1kumakore_1_1_leaderboard_member.html#a4b0f7919047f2569b0fefbda17816cac", null ],
    [ "isFriend", "classcom_1_1kumakore_1_1_leaderboard_member.html#a63df9f717e81c4ff97a8c7cf92464100", null ],
    [ "isFriendFacebook", "classcom_1_1kumakore_1_1_leaderboard_member.html#aefdaddf85e0a5c47255fb644d20d4661", null ]
];