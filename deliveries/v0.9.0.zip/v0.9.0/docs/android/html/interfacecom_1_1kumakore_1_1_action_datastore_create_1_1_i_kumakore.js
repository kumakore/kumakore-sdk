var interfacecom_1_1kumakore_1_1_action_datastore_create_1_1_i_kumakore =
[
    [ "onActionDatastoreCreate", "interfacecom_1_1kumakore_1_1_action_datastore_create_1_1_i_kumakore.html#aa63cfd7f3bfc428616acb8d33e7b28af", null ]
];