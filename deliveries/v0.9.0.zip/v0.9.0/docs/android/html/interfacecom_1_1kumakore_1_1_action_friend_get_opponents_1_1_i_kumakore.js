var interfacecom_1_1kumakore_1_1_action_friend_get_opponents_1_1_i_kumakore =
[
    [ "onActionFriendGetOpponents", "interfacecom_1_1kumakore_1_1_action_friend_get_opponents_1_1_i_kumakore.html#ad1b6684dcba3332bd0dca8c6890299e8", null ]
];