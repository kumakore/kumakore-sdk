var classcom_1_1kumakore_1_1_action_friend_invitation_response =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_friend_invitation_response_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_friend_invitation_response_1_1_i_kumakore" ],
    [ "ActionFriendInvitationResponse", "classcom_1_1kumakore_1_1_action_friend_invitation_response.html#a282b5228f327270599d33328da717254", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_friend_invitation_response.html#aaec329228aa8e90d9e6595ed93b836c1", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_friend_invitation_response.html#a230ef397b7c042003e2347558368f960", null ]
];