var classcom_1_1kumakore_1_1_friend_list =
[
    [ "InviteResponse", "enumcom_1_1kumakore_1_1_friend_list_1_1_invite_response.html", "enumcom_1_1kumakore_1_1_friend_list_1_1_invite_response" ],
    [ "FriendList", "classcom_1_1kumakore_1_1_friend_list.html#a9517af1643097a3901f41dde4a3c8fc1", null ],
    [ "deleteFriend", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#gaf9054605179801b8439c7e318f5aa9dd", null ],
    [ "deleteFriend", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga21cff7a9bf8d19dfdfdc370381fdc612", null ],
    [ "getFriendInvitations", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#gaf87364572d2d63c5d7bc64b7304b74a7", null ],
    [ "getInvitedFriends", "classcom_1_1kumakore_1_1_friend_list.html#abb12cdf7ffd980af4fa542e1fbe47b9c", null ],
    [ "getOpponents", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga521c9af8e00a7cd9edca91a5a38db262", null ],
    [ "sendFriendInvite", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga284dad9a270d48740f2162106d6835b8", null ],
    [ "sendInviteResponse", "group___a_c_t_i_o_n_s___f_r_i_e_n_d.html#ga7535dbbd4ee199027f4fb16a71e1e0b0", null ],
    [ "friendInvitations", "classcom_1_1kumakore_1_1_friend_list.html#a91655a652513c0070683816f07ac1219", null ],
    [ "invitedFriends", "classcom_1_1kumakore_1_1_friend_list.html#abc83d85645faa49b30f7aa31eea70cfc", null ],
    [ "opponents", "classcom_1_1kumakore_1_1_friend_list.html#ae3035900f008370ab0540b879b6bf44c", null ]
];