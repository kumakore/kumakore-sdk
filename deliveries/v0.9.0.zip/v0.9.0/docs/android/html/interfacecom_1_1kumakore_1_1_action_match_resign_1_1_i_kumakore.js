var interfacecom_1_1kumakore_1_1_action_match_resign_1_1_i_kumakore =
[
    [ "onActionMatchResign", "interfacecom_1_1kumakore_1_1_action_match_resign_1_1_i_kumakore.html#a3b11d438dbf180f59a378550337774a2", null ]
];