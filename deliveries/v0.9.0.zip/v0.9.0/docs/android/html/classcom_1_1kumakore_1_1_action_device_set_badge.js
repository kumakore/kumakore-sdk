var classcom_1_1kumakore_1_1_action_device_set_badge =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_device_set_badge_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_device_set_badge_1_1_i_kumakore" ],
    [ "ActionDeviceSetBadge", "classcom_1_1kumakore_1_1_action_device_set_badge.html#a78a004b970edc98909f496a48c1f4515", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_device_set_badge.html#a370fa908e52887a020b370a3ab21e0c9", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_device_set_badge.html#a91c7dbaa9b8b4de0dea67052d283566f", null ]
];