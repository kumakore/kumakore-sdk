var classcom_1_1kumakore_1_1_action_match_get_moves =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_get_moves_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_get_moves_1_1_i_kumakore" ],
    [ "ActionMatchGetMoves", "classcom_1_1kumakore_1_1_action_match_get_moves.html#a537a873672fcd53d05c515e9301f5b46", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_get_moves.html#a25f7e28a24d17aece30296cd5c33fee8", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_get_moves.html#ae0f84a462f063e7794d466d22e785d8b", null ]
];