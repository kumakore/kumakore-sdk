var enumcom_1_1kumakore_1_1_friend_list_1_1_invite_response =
[
    [ "accept", "enumcom_1_1kumakore_1_1_friend_list_1_1_invite_response.html#a833393a22b692fdef3c7aed4ab1370ca", null ],
    [ "block", "enumcom_1_1kumakore_1_1_friend_list_1_1_invite_response.html#a9d093af93fddf83eaf0fd3aac6e4fc3f", null ],
    [ "reject", "enumcom_1_1kumakore_1_1_friend_list_1_1_invite_response.html#a270143b8a2c508c95fb3ca5d9022ab6e", null ]
];