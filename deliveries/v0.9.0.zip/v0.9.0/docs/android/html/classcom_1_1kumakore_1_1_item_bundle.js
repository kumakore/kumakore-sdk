var classcom_1_1kumakore_1_1_item_bundle =
[
    [ "getName", "classcom_1_1kumakore_1_1_item_bundle.html#ae333555ace5257b320d1ade8e95685a2", null ],
    [ "getQuantity", "classcom_1_1kumakore_1_1_item_bundle.html#afdf3841be552939c702e3d032050c00d", null ]
];