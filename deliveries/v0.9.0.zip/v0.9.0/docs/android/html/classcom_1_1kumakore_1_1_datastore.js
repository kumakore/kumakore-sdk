var classcom_1_1kumakore_1_1_datastore =
[
    [ "create", "classcom_1_1kumakore_1_1_datastore.html#a587f76583af29acb8a7319acb534f7d6", null ],
    [ "delete", "classcom_1_1kumakore_1_1_datastore.html#a165ea6e19c02685c8d15765989f83cd4", null ],
    [ "get", "classcom_1_1kumakore_1_1_datastore.html#a8f4acd685be6e05671606d9e4a4f474c", null ],
    [ "get", "classcom_1_1kumakore_1_1_datastore.html#a796aef31b1551e08b5a25cb70b7d5524", null ],
    [ "update", "classcom_1_1kumakore_1_1_datastore.html#ae1f4a7abd9b2e6bc5b9f21129aa366a3", null ]
];