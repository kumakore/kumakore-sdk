var classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor =
[
    [ "clear", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor.html#a9ab8c56e3de0347d36fc16bcb24123a2", null ],
    [ "commit", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor.html#a5cf1f8e14e57ead21b803ded25c95cc8", null ],
    [ "putBoolean", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor.html#a4bef14a92794d452c779abf23d9e188e", null ],
    [ "putInt", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor.html#a23894ee2dd142732e8cdac042c61cda6", null ],
    [ "putString", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor.html#ab670f44bcd23e1783b79c66b808c86b1", null ],
    [ "remove", "classcom_1_1kumakore_1_1_kumakore_preferences_1_1_editor.html#a7a212d5275ed4928c21386990537680a", null ]
];