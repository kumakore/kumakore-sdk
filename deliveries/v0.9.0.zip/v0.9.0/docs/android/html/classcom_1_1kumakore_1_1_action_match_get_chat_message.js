var classcom_1_1kumakore_1_1_action_match_get_chat_message =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_match_get_chat_message_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_match_get_chat_message_1_1_i_kumakore" ],
    [ "ActionMatchGetChatMessage", "classcom_1_1kumakore_1_1_action_match_get_chat_message.html#ab3dec212013591804477425cb0ba64b5", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_match_get_chat_message.html#a65489565c12ebec014d726a482fa3010", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_match_get_chat_message.html#a3b924e2b78cde023d8329605475c5471", null ]
];