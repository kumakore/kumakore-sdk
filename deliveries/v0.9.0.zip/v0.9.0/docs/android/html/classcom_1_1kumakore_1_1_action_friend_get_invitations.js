var classcom_1_1kumakore_1_1_action_friend_get_invitations =
[
    [ "IKumakore", "interfacecom_1_1kumakore_1_1_action_friend_get_invitations_1_1_i_kumakore.html", "interfacecom_1_1kumakore_1_1_action_friend_get_invitations_1_1_i_kumakore" ],
    [ "ActionFriendGetInvitations", "classcom_1_1kumakore_1_1_action_friend_get_invitations.html#ac9e888f61c3d460a098394a05a1e259d", null ],
    [ "onRequest", "classcom_1_1kumakore_1_1_action_friend_get_invitations.html#a4fedc658333770b10fb4999d1ff64c31", null ],
    [ "onResponse", "classcom_1_1kumakore_1_1_action_friend_get_invitations.html#af22d2af40082299ae76df38be6610c4d", null ]
];